package com.jacaranda.entity;

public enum tipoCategory {
	DRAMA,COMEDIA,ACCION,ANIMACION

}
